function p = hnPdf(x,theta)
p=2*normpdf(x,0,theta.sigma);
p(x<0)=0;
end

